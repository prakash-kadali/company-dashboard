
package com.example.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.User;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
//import com.example.repository.SalaryRepository;
import com.example.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private DesignationRepository desigRepo; 
    @Autowired private EmployeeRepository empRepo;  
  
    @Autowired private UserRepository userRepo;
   
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; 
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        Optional<User> optionalUser = userRepo.findByEmailAndPasswordAndRole(email, password,role);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("User found in DB - Email: " + user.getEmail() + ", Password: " + user.getPassword() + ", Role: " + user.getRole());

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            if (!user.getRole().equals(role)) {
                model.addAttribute("error", "Incorrect role selected");
                return "login";
            }

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("password", user.getPassword());

            if ("admin".equals(role)) {
                System.out.println("Redirecting");

                return "redirect:/admin-dashboard";
                
            } else if ("employee".equals(role)) {
                return "redirect:/emp-dashboard";
            }
        }

        model.addAttribute("error", "Invalid credentials");
        return "login";
    }
    @GetMapping("/admin-dashboard")
    public String showDashboard(Model model) {
    	 List<Department> departments = deptRepo.findAll();
    	 System.out.println("Departments");
         model.addAttribute("departments", departments);
             model.addAttribute("designations", desigRepo.findAll());
             model.addAttribute("employees", empRepo.findAll());
             model.addAttribute("users", userRepo.findAll());
           //model.addAttribute("salaries", salRepo.findAll());
          // model.addAttribute("leaves", leaveRequestRepo.findAll());

           
        return "admin-dashboard"; 
    }
    @GetMapping("/emp-dashboard")
    public String showwDashboard(Model model) {
    	List<Department> departments = deptRepo.findAll();
    	List<Designation> designations = desigRepo.findAll();
    	List<Employee> employees = empRepo.findAll();
    	List<User> users = userRepo.findAll();
        model.addAttribute("departments", departments);
        model.addAttribute("designations",designations);
        model.addAttribute("employees",employees);
        model.addAttribute("users",users);
        return "emp-dashboard"; 
    }

    @PostMapping("/addDepartment")
    public String addDepartment(@RequestParam Long dept_id,@RequestParam String name,
    		@RequestParam Date created_date,@RequestParam String mail, RedirectAttributes redirectAttributes) {
        Department dept = new Department();
        dept.setDept_id(dept_id);
        dept.setName(name);
        dept.setCreated_date
        (created_date);
        dept.setMail(mail);
        deptRepo.save(dept);
        redirectAttributes.addFlashAttribute("message", "Department added successfully");
        return "redirect:/admin-dashboard?tab=departments";
    }

    @PostMapping("/deleteDepartment")
    public String deleteDepartment(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        deptRepo.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Department deleted successfully");
        return "redirect:/admin-dashboard?tab=departments";

    }
    @PostMapping("/deleteDesignation")
    public String deleteDesignation(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        desigRepo.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Designation deleted successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }

    @PostMapping("/addDesignation")
    public String addDesignation(@RequestParam Long desig_id,
    		@RequestParam("title") String title,@RequestParam Date created_date,@RequestParam String dmail,RedirectAttributes redirectAttributes) {
        Designation designation = new Designation();
        //designation.setDesig_id(desig_id);
        designation.setTitle(title);
        designation.setDesig_id(desig_id);
        designation.setDmail(dmail);
        designation.setCreated_date(created_date);
        desigRepo.save(designation);
        redirectAttributes.addFlashAttribute("message", "Designation added successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }
    @PostMapping("/deleteEmployee")
    public String deleteEmployee(@RequestParam("id") Long emp_id, RedirectAttributes redirectAttributes) {
        empRepo.deleteById(emp_id);
        redirectAttributes.addFlashAttribute("message", "Employee deleted successfully.");
        return "redirect:/admin-dashboard?tab=employees";
    }

    @PostMapping("/addEmployee")
    public String addEmployee(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("phone") Long phone,
            @RequestParam("hiredate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hiredate,
           // @RequestParam("first_name") String first_name,
           // @RequestParam("last_name") String last_name,
            @RequestParam("salary") Double salary,
            @RequestParam Long deptId,
            @RequestParam Long desigId,
            RedirectAttributes redirectAttributes) {

        Employee emp = new Employee();
        Department dept = deptRepo.findById(deptId).orElse(null);
        Designation desig = desigRepo.findById(desigId).orElse(null);
        emp.setName(name);
        emp.setEmail(email);
        emp.setPhone(phone);
        emp.setHiredate(hiredate);
       // emp.setFirst_name(first_name);
        //emp.setLast_name(last_name);
        emp.setSalary(salary);
        emp.setDepartment(dept);
        emp.setDesignation(desig);

        empRepo.save(emp);
        redirectAttributes.addFlashAttribute("message", "Employee added successfully.");
        return "redirect:/admin-dashboard?tab=employees";
        		
    }
    @PostMapping("/add-user")
    public String addUser(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          @RequestParam String role,
                          RedirectAttributes redirectAttributes) {

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        userRepo.save(user);

        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }

    // Delete user
    @PostMapping("/delete-user")
    public String deleteUser(@RequestParam Long id,
                             RedirectAttributes redirectAttributes) {
        userRepo.deleteById(id);
        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
//    @GetMapping("/admin-dashboard")
//    public String dashboard(Model model) {
//        List<Department> departments = deptRepo.findAll();
//        model.addAttribute("departments", departments);
//       
//        return "dashboard"; 
//    }

//
//    @PostMapping("/addDepartment")
//    public String addDepartment(@RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = new Department();
//        dept.setName(name);
//        deptRepo.save(dept);
//        redirectAttributes.addFlashAttribute("message", "Department added.");
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/updateDepartment")
//    public String updateDepartment(@RequestParam Long dept_id, @RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = deptRepo.findById(dept_id).orElse(null);
//        if (dept != null) {
//            dept.setName(name);
//            deptRepo.save(dept);
//            redirectAttributes.addFlashAttribute("message", "Department updated.");
//        }
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/deleteDepartment")
//    public String deleteDepartment(@RequestParam Long dept_id, RedirectAttributes redirectAttributes) {
//        deptRepo.deleteById(dept_id);
//        redirectAttributes.addFlashAttribute("message", "Department deleted.");
//        return "redirect:/admin-dashboard";
//    }
}
