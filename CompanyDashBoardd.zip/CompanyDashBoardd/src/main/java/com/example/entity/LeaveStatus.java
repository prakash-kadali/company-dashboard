package com.example.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
