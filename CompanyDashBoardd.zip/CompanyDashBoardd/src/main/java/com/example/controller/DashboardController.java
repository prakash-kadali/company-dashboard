
package com.example.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.LeaveRequest;
import com.example.entity.LeaveStatus;
import com.example.entity.User;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
import com.example.repository.LeaveRequestRepository;
//import com.example.repository.SalaryRepository;
import com.example.repository.UserRepository;

import jakarta.servlet.http.HttpSession;


@Controller
public class DashboardController {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private DesignationRepository desigRepo; 
    @Autowired private EmployeeRepository empRepo;  
    @Autowired private LeaveRequestRepository leaveRepo;
    @Autowired private UserRepository userRepo;
   
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; 
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        Optional<User> optionalUser = userRepo.findByEmailAndPasswordAndRole(email, password,role);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("User found in DB - Email: " + user.getEmail() + ", Password: " + user.getPassword() + ", Role: " + user.getRole());

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            if (!user.getRole().equals(role)) {
                model.addAttribute("error", "Incorrect role selected");
                return "login";
            }

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("password", user.getPassword());

            if ("admin".equals(role)) {
                System.out.println("Redirecting");

                return "redirect:/admin-dashboard";
                
            } else if ("employee".equals(role)) {
                return "redirect:/emp-dashboard";
            }
        }

        model.addAttribute("error", "Invalid credentials");
        return "login";
    }
    @GetMapping("/admin-dashboard")
    public String adminDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
            @RequestParam(defaultValue = "departments") String activeTab,
            @RequestParam(required = false) String openPopup,
            Model model) {

        int pageSize = 5;

        // Department pagination
        Pageable deptPageable = PageRequest.of(deptPage, pageSize);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);

        // Designation pagination
        Pageable desigPageable = PageRequest.of(desigPage, pageSize);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);

        // Employee pagination
        Pageable empPageable = PageRequest.of(empPage, pageSize);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);

        // User pagination
        Pageable userPageable = PageRequest.of(userPage, pageSize);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);

//        List<LeaveRequest> leaveRequests = leaveRepo.findAll();
//        model.addAttribute("leaveRequests", leaveRequests);

        // Pass which popup to open
        model.addAttribute("activeTab", activeTab);

        model.addAttribute("openPopup", openPopup);
           
        return "admin-dashboard"; 
    }
    @GetMapping("/emp-dashboard")
    public String showDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
           // @RequestParam(defaultValue = "departmentPopup") String openPopup,
            Model model) {

        int pageSize = 5;

        // Department pagination
        Pageable deptPageable = PageRequest.of(deptPage, pageSize);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);

        // Designation pagination
        Pageable desigPageable = PageRequest.of(desigPage, pageSize);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);

        // Employee pagination
        Pageable empPageable = PageRequest.of(empPage, pageSize);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);

        // User pagination
        Pageable userPageable = PageRequest.of(userPage, pageSize);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);

        // Pass which popup to open
       // model.addAttribute("openPopup", openPopup);

        return "emp-dashboard";
    }



    @PostMapping("/addDepartment")
    public String addDepartment(@RequestParam Long dept_id,@RequestParam String name,
    		@RequestParam Date created_date,@RequestParam String mail, RedirectAttributes redirectAttributes) {
        Department dept = new Department();
        dept.setDept_id(dept_id);
        dept.setName(name);
        dept.setCreated_date
        (created_date);
        dept.setMail(mail);
        deptRepo.save(dept);
        redirectAttributes.addFlashAttribute("message", "Department added successfully");
        return "redirect:/admin-dashboard?tab=departments";
    }

    @PostMapping("/deleteDepartment")
    public String deleteDepartment(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        deptRepo.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Department deleted successfully");
        return "redirect:/admin-dashboard?tab=departments";

    }
    @PostMapping("/deleteDesignation")
    public String deleteDesignation(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        desigRepo.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Designation deleted successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }

    @PostMapping("/addDesignation")
    public String addDesignation(@RequestParam Long desig_id,
    		@RequestParam("title") String title,@RequestParam Date created_date,@RequestParam String dmail,RedirectAttributes redirectAttributes) {
        Designation desig = new Designation();
        //designation.setDesig_id(desig_id);
        desig.setTitle(title);
        desig.setDesig_id(desig_id);
        desig.setDmail(dmail);
        desig.setCreated_date(created_date);
        desigRepo.save(desig);
        redirectAttributes.addFlashAttribute("message", "Designation added successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }
    @PostMapping("/deleteEmployee")
    public String deleteEmployee(@RequestParam("id") Long emp_id, RedirectAttributes redirectAttributes) {
        empRepo.deleteById(emp_id);
        redirectAttributes.addFlashAttribute("message", "Employee deleted successfully.");
        return "redirect:/admin-dashboard?tab=employees";
    }

    @PostMapping("/addEmployee")
    public String addEmployee(
    		@RequestParam("emp_id") Long emp_id,
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("phone") Long phone,
            @RequestParam("hiredate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hiredate,
           @RequestParam("first_name") String first_name,
           @RequestParam("last_name") String last_name,
            @RequestParam("salary") Double salary,
            @RequestParam("dept_id") Long dept_id,
            @RequestParam("desig_id") Long desig_id,
            RedirectAttributes redirectAttributes) {

        Employee emp = new Employee();
        Department dept = deptRepo.findById(dept_id).orElse(null);
        Designation desig = desigRepo.findById(desig_id).orElse(null);
        emp.setEmp_id(emp_id);
        emp.setName(name);
        emp.setEmail(email);
        emp.setPhone(phone);
        emp.setHiredate(hiredate);
        emp.setFirst_name(first_name);
        emp.setLast_name(last_name);
        emp.setSalary(salary);
        emp.setDept(dept);
        emp.setDesig(desig);

        empRepo.save(emp);
        redirectAttributes.addFlashAttribute("message", "Employee added successfully.");
        return "redirect:/admin-dashboard?tab=employees";
        		
    }
    @PostMapping("/add-user")
    public String addUser(@RequestParam Long user_id,
    		              @RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          @RequestParam String role,
                          RedirectAttributes redirectAttributes) {

        User user = new User();
        user.setUser_id(user_id);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        userRepo.save(user);

        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }

    // Delete user
    @PostMapping("/delete-user")
    public String deleteUser(@RequestParam Long id,
                             RedirectAttributes redirectAttributes) {
        userRepo.deleteById(id);
        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }
//    @PostMapping("/employee/apply-leave")
//    public String applyLeave(@RequestParam String startDate,
//                              @RequestParam String endDate,
//                              @RequestParam String reason,
//                              @RequestParam Long empId) {
//        LeaveRequest leave = new LeaveRequest();
//        leave.setStartDate(LocalDate.parse(startDate));
//        leave.setEndDate(LocalDate.parse(endDate));
//        leave.setReason(reason);
//
//        Employee emp = empRepo.findById(empId).orElse(null);
//        leave.setEmployee(emp);
//        leaveRepo.save(leave);
//
//        return "redirect:/emp-dashboard?leaveSubmitted=true";
//    }
//
//    // Show leave requests on admin dashboard
//    @GetMapping("/admin-dashboard/leaves")
//    public String showAllLeaveRequests(Model model) {
//        List<LeaveRequest> leaveList = leaveRepo.findAll();
//        model.addAttribute("leaveRequests", leaveList);
//        return "admin-dashboard"; // Part of existing admin page
//    }
//
//    // Admin approves or rejects
//    @PostMapping("/admin/leave-action")
//    public String handleLeaveAction(@RequestParam Long leaveId, @RequestParam String action) {
//        LeaveRequest leave = leaveRepo.findById(leaveId).orElse(null);
//        if (leave != null) {
//            if ("approve".equalsIgnoreCase(action)) {
//                leave.setStatus(LeaveStatus.APPROVED);
//            } else if ("reject".equalsIgnoreCase(action)) {
//                leave.setStatus(LeaveStatus.REJECTED);
//            }
//            leaveRepo.save(leave);
//        }
//        return "redirect:/admin-dashboard?tab=leaves";
//    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
//    @GetMapping("/admin-dashboard")
//    public String dashboard(Model model) {
//        List<Department> departments = deptRepo.findAll();
//        model.addAttribute("departments", departments);
//       
//        return "dashboard"; 
//    }

//
//    @PostMapping("/addDepartment")
//    public String addDepartment(@RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = new Department();
//        dept.setName(name);
//        deptRepo.save(dept);
//        redirectAttributes.addFlashAttribute("message", "Department added.");
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/updateDepartment")
//    public String updateDepartment(@RequestParam Long dept_id, @RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = deptRepo.findById(dept_id).orElse(null);
//        if (dept != null) {
//            dept.setName(name);
//            deptRepo.save(dept);
//            redirectAttributes.addFlashAttribute("message", "Department updated.");
//        }
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/deleteDepartment")
//    public String deleteDepartment(@RequestParam Long dept_id, RedirectAttributes redirectAttributes) {
//        deptRepo.deleteById(dept_id);
//        redirectAttributes.addFlashAttribute("message", "Department deleted.");
//        return "redirect:/admin-dashboard";
//    }
}
