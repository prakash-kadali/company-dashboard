-- Create database
CREATE DATABASE IF NOT EXISTS company_dashboard;
USE company_dashboard;

-- Create UserRole enum table
CREATE TABLE IF NOT EXISTS user_roles (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(20) NOT NULL UNIQUE
);

-- Create Department table
CREATE TABLE IF NOT EXISTS departments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Designation table
CREATE TABLE IF NOT EXISTS designations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    department_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    UNIQUE KEY unique_designation_dept (name, department_id)
);

-- Create User table
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL,
    designation_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES user_roles(id),
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (designation_id) REFERENCES designations(id)
);

-- Create LeaveStatus enum table
CREATE TABLE IF NOT EXISTS leave_statuses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(20) NOT NULL UNIQUE
);

-- Create LeaveRequest table
CREATE TABLE IF NOT EXISTS leave_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status_id BIGINT NOT NULL,
    admin_comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (status_id) REFERENCES leave_statuses(id)
);

-- Insert UserRoles
INSERT INTO user_roles (name) VALUES
('ADMIN'),
('EMPLOYEE');

-- Insert LeaveStatuses
INSERT INTO leave_statuses (name) VALUES
('PENDING'),
('APPROVED'),
('REJECTED');

-- Insert Departments
INSERT INTO departments (name) VALUES
('Information Technology'),
('Human Resources'),
('Finance');

-- Insert Designations
INSERT INTO designations (name, department_id) VALUES
('Senior Developer', 1),
('Junior Developer', 1),
('HR Manager', 2),
('Finance Manager', 3);

-- Insert Users (passwords are BCrypt encoded)
INSERT INTO users (name, email, password, role_id, department_id, designation_id) VALUES
('Admin User', 'admin@company.com', '$2a$10$rDkPvvAFV6GgJkKq8WU1UOQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQ', 1, 1, 1),
('John Doe', 'john@company.com', '$2a$10$rDkPvvAFV6GgJkKq8WU1UOQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQ', 2, 1, 1),
('Jane Smith', 'jane@company.com', '$2a$10$rDkPvvAFV6GgJkKq8WU1UOQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQ', 2, 2, 3),
('Mike Johnson', 'mike@company.com', '$2a$10$rDkPvvAFV6GgJkKq8WU1UOQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQ', 2, 3, 4);

-- Sample Leave Requests
INSERT INTO leave_requests (user_id, start_date, end_date, reason, status_id, admin_comment) VALUES
(2, '2024-03-20', '2024-03-22', 'Family emergency', 1, NULL),
(3, '2024-03-25', '2024-03-26', 'Doctor appointment', 2, 'Approved as per policy'),
(4, '2024-04-01', '2024-04-05', 'Vacation', 3, 'Rejected due to critical project deadline');

-- Sample Queries

-- Get all departments with their designations
SELECT d.name as department_name, des.name as designation_name
FROM departments d
LEFT JOIN designations des ON d.id = des.department_id
ORDER BY d.name, des.name;

-- Get all users with their department and designation
SELECT u.name, u.email, d.name as department, des.name as designation, ur.name as role
FROM users u
JOIN departments d ON u.department_id = d.id
JOIN designations des ON u.designation_id = des.id
JOIN user_roles ur ON u.role_id = ur.id
ORDER BY d.name, des.name;

-- Get all leave requests with user details
SELECT lr.id, u.name as employee_name, d.name as department,
       lr.start_date, lr.end_date, lr.reason,
       ls.name as status, lr.admin_comment
FROM leave_requests lr
JOIN users u ON lr.user_id = u.id
JOIN departments d ON u.department_id = d.id
JOIN leave_statuses ls ON lr.status_id = ls.id
ORDER BY lr.created_at DESC;

-- Get department-wise employee count
SELECT d.name as department, COUNT(u.id) as employee_count
FROM departments d
LEFT JOIN users u ON d.id = u.department_id
GROUP BY d.name
ORDER BY employee_count DESC;

-- Get leave requests by status
SELECT ls.name as status, COUNT(lr.id) as request_count
FROM leave_statuses ls
LEFT JOIN leave_requests lr ON ls.id = lr.status_id
GROUP BY ls.name
ORDER BY request_count DESC;

-- Get user's leave history
SELECT u.name, lr.start_date, lr.end_date, lr.reason,
       ls.name as status, lr.admin_comment
FROM users u
JOIN leave_requests lr ON u.id = lr.user_id
JOIN leave_statuses ls ON lr.status_id = ls.id
WHERE u.email = 'john@company.com'
ORDER BY lr.created_at DESC;

-- Get designation-wise employee distribution
SELECT d.name as department, des.name as designation,
       COUNT(u.id) as employee_count
FROM departments d
JOIN designations des ON d.id = des.department_id
LEFT JOIN users u ON des.id = u.designation_id
GROUP BY d.name, des.name
ORDER BY d.name, employee_count DESC; 