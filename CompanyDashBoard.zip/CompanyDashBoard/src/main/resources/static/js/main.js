// Global variables
let currentUser = null;
let userRole = null;

// DOM Elements
const navLinks = document.querySelectorAll('.nav-links li');
const contentSections = document.querySelectorAll('.content-section');
const modal = document.getElementById('modal');
const modalContent = document.getElementById('modalContent');
const closeModal = document.querySelector('.close');
const logoutBtn = document.getElementById('logoutBtn');

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is logged in
    checkAuth();
    
    // Navigation
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            const page = link.getAttribute('data-page');
            navigateTo(page);
        });
    });

    // Modal close
    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Logout
    logoutBtn.addEventListener('click', handleLogout);

    // Add button event listeners
    document.getElementById('addDepartmentBtn')?.addEventListener('click', () => showAddDepartmentModal());
    document.getElementById('addDesignationBtn')?.addEventListener('click', () => showAddDesignationModal());
    document.getElementById('addUserBtn')?.addEventListener('click', () => showAddUserModal());
    document.getElementById('applyLeaveBtn')?.addEventListener('click', () => showApplyLeaveModal());
});

// Authentication Functions
function checkAuth() {
    // Check if user is logged in (you'll need to implement this with your backend)
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = '/login.html';
        return;
    }

    // Get user role and set permissions
    fetch('/api/user/profile', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        currentUser = data;
        userRole = data.role;
        document.getElementById('userName').textContent = data.name;
        setPermissions();
    })
    .catch(error => {
        console.error('Error fetching user profile:', error);
        window.location.href = '/login.html';
    });
}

function setPermissions() {
    // Hide/show elements based on user role
    const adminOnlyElements = document.querySelectorAll('.admin-only');
    const employeeOnlyElements = document.querySelectorAll('.employee-only');

    if (userRole === 'ADMIN') {
        adminOnlyElements.forEach(el => el.style.display = 'block');
        employeeOnlyElements.forEach(el => el.style.display = 'none');
    } else {
        adminOnlyElements.forEach(el => el.style.display = 'none');
        employeeOnlyElements.forEach(el => el.style.display = 'block');
    }
}

function handleLogout() {
    localStorage.removeItem('token');
    window.location.href = '/login.html';
}

// Navigation Functions
function navigateTo(page) {
    // Update active nav link
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === page) {
            link.classList.add('active');
        }
    });

    // Show corresponding content section
    contentSections.forEach(section => {
        section.classList.add('hidden');
        if (section.id === page) {
            section.classList.remove('hidden');
            loadSectionData(page);
        }
    });
}

// Data Loading Functions
function loadSectionData(section) {
    switch(section) {
        case 'departments':
            loadDepartments();
            break;
        case 'designations':
            loadDesignations();
            break;
        case 'users':
            loadUsers();
            break;
        case 'salaries':
            loadSalaries();
            break;
        case 'leave-requests':
            loadLeaveRequests();
            break;
    }
}

// Modal Functions
function showModal(content) {
    modalContent.innerHTML = content;
    modal.style.display = 'block';
}

// Department Functions
function loadDepartments() {
    fetch('/api/departments', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
    })
    .then(response => response.json())
    .then(departments => {
        const tbody = document.querySelector('#departmentsTable tbody');
        tbody.innerHTML = departments.map(dept => `
            <tr>
                <td>${dept.id}</td>
                <td>${dept.name}</td>
                <td>
                    <button class="action-btn edit-btn" onclick="editDepartment(${dept.id})">Edit</button>
                    <button class="action-btn delete-btn" onclick="deleteDepartment(${dept.id})">Delete</button>
                </td>
            </tr>
        `).join('');
    })
    .catch(error => console.error('Error loading departments:', error));
}

function showAddDepartmentModal() {
    const content = `
        <h3>Add Department</h3>
        <form id="addDepartmentForm">
            <div class="form-group">
                <label for="deptName">Department Name</label>
                <input type="text" id="deptName" required>
            </div>
            <button type="submit" class="btn-primary">Add Department</button>
        </form>
    `;
    showModal(content);

    document.getElementById('addDepartmentForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('deptName').value;
        addDepartment(name);
    });
}

// Similar functions for other sections (Designations, Users, Salaries, Leave Requests)
// You'll need to implement these based on your backend API

// Utility Functions
function formatDate(date) {
    return new Date(date).toLocaleDateString();
}

function showError(message) {
    alert(message); // Replace with a better error display mechanism
}

function showSuccess(message) {
    alert(message); // Replace with a better success display mechanism
} 