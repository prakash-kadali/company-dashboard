package com.company.dashboard.service;

import com.company.dashboard.entity.Designation;
import com.company.dashboard.repository.DesignationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DesignationService {
    @Autowired
    private DesignationRepository designationRepository;

    public List<Designation> getAllDesignations() {
        return designationRepository.findAll();
    }

    public List<Designation> getDesignationsByDepartment(Long departmentId) {
        return designationRepository.findByDepartmentId(departmentId);
    }

    public Designation getDesignationById(Long id) {
        return designationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Designation not found"));
    }

    public Designation createDesignation(Designation designation) {
        return designationRepository.save(designation);
    }

    public Designation updateDesignation(Long id, Designation designationDetails) {
        Designation designation = designationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Designation not found"));

        designation.setName(designationDetails.getName());
        designation.setDepartment(designationDetails.getDepartment());
        return designationRepository.save(designation);
    }

    public void deleteDesignation(Long id) {
        designationRepository.deleteById(id);
    }
} 