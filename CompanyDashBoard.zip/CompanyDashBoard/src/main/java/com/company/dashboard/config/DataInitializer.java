package com.company.dashboard.config;

import com.company.dashboard.entity.Department;
import com.company.dashboard.entity.Designation;
import com.company.dashboard.entity.User;
import com.company.dashboard.entity.UserRole;
import com.company.dashboard.repository.DepartmentRepository;
import com.company.dashboard.repository.DesignationRepository;
import com.company.dashboard.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private DesignationRepository designationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create Departments
        Department itDept = new Department();
        itDept.setName("Information Technology");
        departmentRepository.save(itDept);

        Department hrDept = new Department();
        hrDept.setName("Human Resources");
        departmentRepository.save(hrDept);

        Department financeDept = new Department();
        financeDept.setName("Finance");
        departmentRepository.save(financeDept);

        // Create Designations
        Designation seniorDev = new Designation();
        seniorDev.setName("Senior Developer");
        seniorDev.setDepartment(itDept);
        designationRepository.save(seniorDev);

        Designation juniorDev = new Designation();
        juniorDev.setName("Junior Developer");
        juniorDev.setDepartment(itDept);
        designationRepository.save(juniorDev);

        Designation hrManager = new Designation();
        hrManager.setName("HR Manager");
        hrManager.setDepartment(hrDept);
        designationRepository.save(hrManager);

        Designation financeManager = new Designation();
        financeManager.setName("Finance Manager");
        financeManager.setDepartment(financeDept);
        designationRepository.save(financeManager);

        // Create Users
        // Admin User
        User admin = new User();
        admin.setName("Admin User");
        admin.setEmail("admin@company.com");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRole(UserRole.ADMIN);
        admin.setDepartment(itDept);
        admin.setDesignation(seniorDev);
        userRepository.save(admin);

        // IT Employee
        User itEmployee = new User();
        itEmployee.setName("John Doe");
        itEmployee.setEmail("john@company.com");
        itEmployee.setPassword(passwordEncoder.encode("employee123"));
        itEmployee.setRole(UserRole.EMPLOYEE);
        itEmployee.setDepartment(itDept);
        itEmployee.setDesignation(juniorDev);
        userRepository.save(itEmployee);

        // HR Employee
        User hrEmployee = new User();
        hrEmployee.setName("Jane Smith");
        hrEmployee.setEmail("jane@company.com");
        hrEmployee.setPassword(passwordEncoder.encode("employee123"));
        hrEmployee.setRole(UserRole.EMPLOYEE);
        hrEmployee.setDepartment(hrDept);
        hrEmployee.setDesignation(hrManager);
        userRepository.save(hrEmployee);

        // Finance Employee
        User financeEmployee = new User();
        financeEmployee.setName("Mike Johnson");
        financeEmployee.setEmail("mike@company.com");
        financeEmployee.setPassword(passwordEncoder.encode("employee123"));
        financeEmployee.setRole(UserRole.EMPLOYEE);
        financeEmployee.setDepartment(financeDept);
        financeEmployee.setDesignation(financeManager);
        userRepository.save(financeEmployee);
    }
} 