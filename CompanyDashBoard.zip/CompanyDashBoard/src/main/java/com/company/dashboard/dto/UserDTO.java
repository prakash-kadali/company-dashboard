package com.company.dashboard.dto;

import com.company.dashboard.entity.UserRole;
import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String name;
    private String email;
    private UserRole role;
    private Long departmentId;
    private Long designationId;
    private String departmentName;
    private String designationName;
} 