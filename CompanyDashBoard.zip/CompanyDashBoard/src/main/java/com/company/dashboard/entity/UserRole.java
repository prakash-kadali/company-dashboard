package com.company.dashboard.entity;

public enum UserRole {
    ADMIN,
    EMPLOYEE
} 