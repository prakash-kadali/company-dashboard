package com.company.dashboard.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
} 