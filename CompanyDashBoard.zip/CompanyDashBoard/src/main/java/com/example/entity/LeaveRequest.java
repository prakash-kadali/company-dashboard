package com.example.entity;

import java.time.LocalDate;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class LeaveRequest {
    @Id @GeneratedValue
    private Long id;
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;

//    @ManyToOne
//    private Employee employee;
}

