package com.example.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;
@Data
@Entity
public class Designation {
    @Id @GeneratedValue
    private Long desig_id;
    private String title;

//    @OneToMany(mappedBy = "designation")
//    private List<Employee> employees;
}