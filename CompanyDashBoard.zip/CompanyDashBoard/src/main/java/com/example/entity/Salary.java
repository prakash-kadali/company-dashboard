package com.example.entity;

import java.time.LocalDate;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Data;
@Data
@Entity
public class Salary {
    @Id @GeneratedValue
    private Long id;
    private Double amount;
    private LocalDate paidDate;

    @ManyToOne
    private Employee employee;
}
