package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn; // ADD THIS IMPORT
import jakarta.persistence.OneToOne; // ADD THIS IMPORT
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_id")
    private Long userId;
    private String username;
    private String password;
    private String role; // ADMIN or EMPLOYEE
    private String email;

   
    @OneToOne
    @JoinColumn(name = "employee_emp_id", referencedColumnName = "emp_id", unique = true)
   
    private Employee employee;

    // Lombok's @Data will handle getters and setters.
}