package com.example.entity;



import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long emp_id;
    private String name;

    @ManyToOne
    private Department department;

    @ManyToOne
    private Designation designation;
    
    private String email;
    private Long phone;
    private Date hiredate;
    private String first_name;
    private String last_name;
    private Double salary;
    private String password;
    

//    @OneToOne(mappedBy = "employee")
//    private User user;
}