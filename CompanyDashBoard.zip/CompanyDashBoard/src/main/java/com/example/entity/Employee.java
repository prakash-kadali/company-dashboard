package com.example.entity;



import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="emp_id")
    private Long empId;
    private String name;

    @ManyToOne(optional = false)
    @JoinColumn(name = "dept_id", nullable = false)
    private Department dept;

    @ManyToOne(optional = false)
    @JoinColumn(name = "desig_id", nullable = false)
    private Designation desig;

//    
    private String email;
    private Long phone;
    private LocalDate hiredate;
    private String first_name;
    private String last_name;
    private Double salary;
    private String password;
    private Long accountNumber;
    
    

//    @OneToOne(mappedBy = "employee")
//    private User user;
}