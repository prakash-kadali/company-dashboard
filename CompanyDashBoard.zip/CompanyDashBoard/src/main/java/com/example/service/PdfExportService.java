package com.example.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.User;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;
@Service
public class PdfExportService {

    private void addTableHeader(PdfPTable table, String[] headers) {
        for (String header : headers) {
            PdfPCell headerCell = new PdfPCell();
            headerCell.setPhrase(new Phrase(header, FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
            table.addCell(headerCell);
        }
    }

    public void exportDepartmentsToPdf(List<Department> departments, HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        prepareResponse(response, "departments.pdf", "application/pdf");
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        document.add(new Paragraph("Departments List", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK)));
        document.add(Chunk.NEWLINE);

        PdfPTable table = new PdfPTable(4); // 4 columns
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        addTableHeader(table, new String[]{"Department ID", "Name", "Created Date", "Mail"});

        for (Department dept : departments) {
            table.addCell(String.valueOf(dept.getDeptId()));
            table.addCell(dept.getName());
            table.addCell(dept.getCreatedDate().toString());
            table.addCell(dept.getMail());
        }

        document.add(table);
        document.close();
    }

    public void exportDesignationsToPdf(List<Designation> designations, HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        prepareResponse(response, "designations.pdf", "application/pdf");
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        document.add(new Paragraph("Designations List", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK)));
        document.add(Chunk.NEWLINE);

        PdfPTable table = new PdfPTable(4); // 4 columns
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        addTableHeader(table, new String[]{"Designation ID", "Title", "Created Date", "Mail"});

        for (Designation desig : designations) {
            table.addCell(String.valueOf(desig.getDesigId()));
            table.addCell(desig.getTitle());
            table.addCell(desig.getCreatedDate().toString());
            table.addCell(desig.getDmail());
        }

        document.add(table);
        document.close();
    }

    public void exportEmployeesToPdf(List<Employee> employees, HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4.rotate()); // Landscape for more columns
        prepareResponse(response, "employees.pdf", "application/pdf");
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        document.add(new Paragraph("Employees List", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK)));
        document.add(Chunk.NEWLINE);

        PdfPTable table = new PdfPTable(11); // 11 columns
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);
        table.setWidths(new float[]{1.5f, 2f, 2.5f, 1.5f, 2f, 2f, 2f, 1.5f, 2f, 2f, 2f}); // Adjust column widths

        addTableHeader(table, new String[]{"Emp ID", "Name", "Email", "Phone", "Hire Date", "First Name", "Last Name", "Salary", "Dept", "Desig", "Acc Num"});

        for (Employee emp : employees) {
            table.addCell(String.valueOf(emp.getEmpId()));
            table.addCell(emp.getName());
            table.addCell(emp.getEmail());
            table.addCell(String.valueOf(emp.getPhone()));
            table.addCell(emp.getHiredate() != null ? emp.getHiredate().toString() : "");
            table.addCell(emp.getFirstName());
            table.addCell(emp.getLastName());
            table.addCell(String.valueOf(emp.getSalary()));
            table.addCell(emp.getDept() != null ? emp.getDept().getName() : "N/A");
            table.addCell(emp.getDesig() != null ? emp.getDesig().getTitle() : "N/A");
            table.addCell(String.valueOf(emp.getAccountNumber()));
        }

        document.add(table);
        document.close();
    }

    public void exportUsersToPdf(List<User> users, HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        prepareResponse(response, "users.pdf", "application/pdf");
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        document.add(new Paragraph("Users List", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK)));
        document.add(Chunk.NEWLINE);

        PdfPTable table = new PdfPTable(4); // 4 columns
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        addTableHeader(table, new String[]{"User ID", "Username", "Email", "Role"});

        for (User user : users) {
            table.addCell(String.valueOf(user.getUserId()));
            table.addCell(user.getUsername());
            table.addCell(user.getEmail());
            table.addCell(user.getRole());
        }

        document.add(table);
        document.close();
    }

    private void prepareResponse(HttpServletResponse response, String filename, String contentType) {
        response.setContentType(contentType);
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=" + filename;
        response.setHeader(headerKey, headerValue);
    }
}