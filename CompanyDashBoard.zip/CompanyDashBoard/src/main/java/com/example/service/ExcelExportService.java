package com.example.service;

import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.User;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
@Service
public class ExcelExportService {

    public void exportDepartmentsToExcel(List<Department> departments, HttpServletResponse response) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Departments");

        Row headerRow = sheet.createRow(0);
        String[] headers = {"Department ID", "Name", "Created Date", "Mail"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

       
        int rowNum = 1;
        for (Department dept : departments) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(dept.getDeptId());
            row.createCell(1).setCellValue(dept.getName());
            row.createCell(2).setCellValue(dept.getCreatedDate().toString()); // Convert Date to String
            row.createCell(3).setCellValue(dept.getMail());
        }

        prepareResponse(response, "departments.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }

    public void exportDesignationsToExcel(List<Designation> designations, HttpServletResponse response) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Designations");

        Row headerRow = sheet.createRow(0);
        String[] headers = {"Designation ID", "Title", "Created Date", "Mail"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        int rowNum = 1;
        for (Designation desig : designations) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(desig.getDesigId());
            row.createCell(1).setCellValue(desig.getTitle());
            row.createCell(2).setCellValue(desig.getCreatedDate().toString());
            row.createCell(3).setCellValue(desig.getDmail());
        }

        prepareResponse(response, "designations.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }

    public void exportEmployeesToExcel(List<Employee> employees, HttpServletResponse response) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Employees");

        Row headerRow = sheet.createRow(0);
        String[] headers = {"Employee ID", "Name", "Email", "Phone", "Hire Date", "First Name", "Last Name", "Salary", "Department", "Designation", "Account Number"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        int rowNum = 1;
        for (Employee emp : employees) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(emp.getEmpId());
            row.createCell(1).setCellValue(emp.getName());
            row.createCell(2).setCellValue(emp.getEmail());
            row.createCell(3).setCellValue(emp.getPhone());
            row.createCell(4).setCellValue(emp.getHiredate() != null ? emp.getHiredate().toString() : "");
            row.createCell(5).setCellValue(emp.getFirstName());
            row.createCell(6).setCellValue(emp.getLastName());
            row.createCell(7).setCellValue(emp.getSalary());
            row.createCell(8).setCellValue(emp.getDept() != null ? emp.getDept().getName() : "N/A");
            row.createCell(9).setCellValue(emp.getDesig() != null ? emp.getDesig().getTitle() : "N/A");
            row.createCell(10).setCellValue(emp.getAccountNumber());
        }

        prepareResponse(response, "employees.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }

    public void exportUsersToExcel(List<User> users, HttpServletResponse response) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Users");

        Row headerRow = sheet.createRow(0);
        String[] headers = {"User ID", "Username", "Email", "Role"}; // Exclude password for security
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        int rowNum = 1;
        for (User user : users) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(user.getUserId());
            row.createCell(1).setCellValue(user.getUsername());
            row.createCell(2).setCellValue(user.getEmail());
            row.createCell(3).setCellValue(user.getRole());
        }

        prepareResponse(response, "users.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }

    private void prepareResponse(HttpServletResponse response, String filename, String contentType) {
        response.setContentType(contentType);
        String headerKey = "Content-Disposition"; 
        String headerValue = "attachment; filename=" + filename;
        response.setHeader(headerKey, headerValue);
    }
}