package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entity.Admins;

public interface AdminRepository extends JpaRepository<Admins, Long> {
    Admins findByUsernameAndPassword(String username, String password);
}
