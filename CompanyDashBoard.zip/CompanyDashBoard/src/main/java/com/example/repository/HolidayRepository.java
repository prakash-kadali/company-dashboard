package com.example.repository; // Adjust package as per your project

import com.example.entity.Holiday;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HolidayRepository extends JpaRepository<Holiday, Long> {

    // Custom query method to find holidays within a specific date range
    List<Holiday> findByDateBetween(LocalDate startDate, LocalDate endDate);

    // To check if a holiday for a specific date already exists
    Optional<Holiday> findByDate(LocalDate date);
}