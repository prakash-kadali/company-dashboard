package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	 //Employee findByEmailAndPassword(String email, String password);
	
}
