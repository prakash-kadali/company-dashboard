package com.example.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort; // Import Sort
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.User;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
import com.example.repository.UserRepository;
import com.example.service.ExcelExportService;
import com.example.service.PdfExportService;
import com.itextpdf.text.DocumentException;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@Controller
public class DashboardController {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private DesignationRepository desigRepo;    
    @Autowired private EmployeeRepository empRepo;    
    @Autowired private UserRepository userRepo;
    @Autowired
    private ExcelExportService excelExportService; 

    @Autowired 
    private PdfExportService pdfExportService;  
    
    @GetMapping("/login")
    public String showLoginForm(@RequestParam(value = "sessionExpired", required = false) String sessionExpired, Model model) {
        if (sessionExpired != null && sessionExpired.equals("true")) {
            model.addAttribute("errorMessage", "Your session has expired. Please log in again.");
        }
        return "login"; 
    }


    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        Optional<User> optionalUser = userRepo.findByEmailAndPasswordAndRole(email, password,role);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("User found in DB - Email: " + user.getEmail() + ", Password: " + user.getPassword() + ", Role: " + user.getRole());

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            if (!user.getRole().equals(role)) {
                model.addAttribute("error", "Incorrect role selected");
                return "login";
            }

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("password", user.getPassword());

            if ("admin".equals(role)) {
                System.out.println("Redirecting");

                return "redirect:/admin-dashboard";
                
            } else if ("employee".equals(role)) {
                return "redirect:/emp-dashboard";
            }
        }

        model.addAttribute("error", "Invalid credentials");
        return "login";
    }

    @GetMapping("/admin-dashboard")
    public String adminDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
            @RequestParam(value = "tab", required = false, defaultValue = "departments") String tab,
            @RequestParam(defaultValue = "5") int deptSize,
            @RequestParam(defaultValue = "5") int desigSize,    
            @RequestParam(defaultValue = "5") int empSize,    
            @RequestParam(defaultValue = "5") int userSize,
            // Department Sorting parameters
            @RequestParam(defaultValue = "deptId") String deptSortField,
            @RequestParam(defaultValue = "asc") String deptSortDir,
            // Designation Sorting parameters
            @RequestParam(defaultValue = "desigId") String desigSortField,
            @RequestParam(defaultValue = "asc") String desigSortDir,
            // Employee Sorting parameters
            @RequestParam(defaultValue = "empId") String empSortField,
            @RequestParam(defaultValue = "asc") String empSortDir,
            // User Sorting parameters
            @RequestParam(defaultValue = "userId") String userSortField,
            @RequestParam(defaultValue = "asc") String userSortDir,
            
            @RequestParam(required = false) String openPopup,
            Model model) {

        if (deptSize < 1 || deptSize > 100) {
            deptSize = 5;
        }
        if (desigSize < 1 || desigSize > 100) {
            desigSize = 5;
        }
        if (empSize < 1 || empSize > 100) {
            empSize = 5;
        }
        if (userSize < 1 || userSize > 100) {
            userSize = 5;
        }

        // Department Pagination and Sorting
        Sort deptSort = Sort.by(deptSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, deptSortField);
        Pageable deptPageable = PageRequest.of(deptPage, deptSize, deptSort);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);
        model.addAttribute("deptSize", deptSize);
        model.addAttribute("deptSortField", deptSortField);
        model.addAttribute("deptSortDir", deptSortDir);

        // Designation Pagination and Sorting
        Sort desigSort = Sort.by(desigSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, desigSortField);
        Pageable desigPageable = PageRequest.of(desigPage, desigSize, desigSort);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);
        model.addAttribute("desigSize", desigSize);
        model.addAttribute("desigSortField", desigSortField);
        model.addAttribute("desigSortDir", desigSortDir);

        // Employee Pagination and Sorting
        Sort empSort = Sort.by(empSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, empSortField);
        Pageable empPageable = PageRequest.of(empPage, empSize, empSort);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);
        model.addAttribute("empSize", empSize);
        model.addAttribute("empSortField", empSortField);
        model.addAttribute("empSortDir", empSortDir);

        // User Pagination and Sorting
        Sort userSort = Sort.by(userSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, userSortField);
        Pageable userPageable = PageRequest.of(userPage, userSize, userSort);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);
        model.addAttribute("userSize", userSize);
        model.addAttribute("userSortField", userSortField);
        model.addAttribute("userSortDir", userSortDir);
        
        
        model.addAttribute("openPopup", openPopup);
        model.addAttribute("activeTab", tab);
            
        return "admin-dashboard";    
    }

    @GetMapping("/emp-dashboard")
    public String showDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
            @RequestParam(defaultValue = "5") int deptSize,
            @RequestParam(defaultValue = "5") int desigSize,    
            @RequestParam(defaultValue = "5") int empSize,    
            @RequestParam(defaultValue = "5") int userSize,
            // Department Sorting parameters
            @RequestParam(defaultValue = "deptId") String deptSortField,
            @RequestParam(defaultValue = "asc") String deptSortDir,
            // Designation Sorting parameters
            @RequestParam(defaultValue = "desigId") String desigSortField,
            @RequestParam(defaultValue = "asc") String desigSortDir,
            // Employee Sorting parameters
            @RequestParam(defaultValue = "empId") String empSortField,
            @RequestParam(defaultValue = "asc") String empSortDir,
            // User Sorting parameters
            @RequestParam(defaultValue = "userId") String userSortField,
            @RequestParam(defaultValue = "asc") String userSortDir,
            
            @RequestParam(required=false) String openPopup,
            Model model) {

        if (deptSize < 1 || deptSize > 100) {
            deptSize = 5;
        }
        if (desigSize < 1 || desigSize > 100) {
            desigSize = 5;
        }
        if (empSize < 1 || empSize > 100) {
            empSize = 5;
        }
        if (userSize < 1 || userSize > 100) {
            userSize = 5;
        }

        // Department Pagination and Sorting
        Sort deptSort = Sort.by(deptSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, deptSortField);
        Pageable deptPageable = PageRequest.of(deptPage, deptSize, deptSort);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);
        model.addAttribute("deptSize", deptSize);
        model.addAttribute("deptSortField", deptSortField);
        model.addAttribute("deptSortDir", deptSortDir);
            
        // Designation Pagination and Sorting
        Sort desigSort = Sort.by(desigSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, desigSortField);
        Pageable desigPageable = PageRequest.of(desigPage, desigSize, desigSort);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);
        model.addAttribute("desigSize", desigSize);
        model.addAttribute("desigSortField", desigSortField);
        model.addAttribute("desigSortDir", desigSortDir);

        // Employee Pagination and Sorting
        Sort empSort = Sort.by(empSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, empSortField);
        Pageable empPageable = PageRequest.of(empPage, empSize, empSort);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);
        model.addAttribute("empSize", empSize);
        model.addAttribute("empSortField", empSortField);
        model.addAttribute("empSortDir", empSortDir);

        // User Pagination and Sorting
        Sort userSort = Sort.by(userSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, userSortField);
        Pageable userPageable = PageRequest.of(userPage, userSize, userSort);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);
        model.addAttribute("userSize", userSize);
        model.addAttribute("userSortField", userSortField);
        model.addAttribute("userSortDir", userSortDir);
        
        model.addAttribute("openPopup", openPopup);

        return "emp-dashboard";
    }
    @GetMapping("/export/departments/excel")
    public void exportDepartmentsToExcel(HttpServletResponse response) throws IOException {
        List<Department> departments = deptRepo.findAll(); // Get all departments
        excelExportService.exportDepartmentsToExcel(departments, response);
    }

    @GetMapping("/export/departments/pdf")
    public void exportDepartmentsToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Department> departments = deptRepo.findAll(); // Get all departments
        pdfExportService.exportDepartmentsToPdf(departments, response);
    }

    @GetMapping("/export/designations/excel")
    public void exportDesignationsToExcel(HttpServletResponse response) throws IOException {
        List<Designation> designations = desigRepo.findAll();
        excelExportService.exportDesignationsToExcel(designations, response);
    }

    @GetMapping("/export/designations/pdf")
    public void exportDesignationsToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Designation> designations = desigRepo.findAll();
        pdfExportService.exportDesignationsToPdf(designations, response);
    }
    
    @GetMapping("/export/employees/excel")
    public void exportEmployeesToExcel(HttpServletResponse response) throws IOException {
        List<Employee> employees = empRepo.findAll();
        excelExportService.exportEmployeesToExcel(employees, response);
    }

    @GetMapping("/export/employees/pdf")
    public void exportEmployeesToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Employee> employees = empRepo.findAll();
        pdfExportService.exportEmployeesToPdf(employees, response);
    }

    @GetMapping("/export/users/excel")
    public void exportUsersToExcel(HttpServletResponse response) throws IOException {
        List<User> users = userRepo.findAll();
        excelExportService.exportUsersToExcel(users, response);
    }

   @GetMapping("/export/users/pdf")
   public void exportUsersToPdf(HttpServletResponse response) throws DocumentException, IOException{
	   List<User> users =userRepo.findAll();
	   pdfExportService.exportUsersToPdf(users,response);
   }
    @PostMapping("/addDepartment")
    public String addDepartment(@RequestParam Long deptId,@RequestParam String name,
            @RequestParam Date createdDate,@RequestParam String mail, RedirectAttributes redirectAttributes) {
        Department dept = new Department();
        dept.setDeptId(deptId);
        dept.setName(name);
        dept.setCreatedDate(createdDate);
        dept.setMail(mail);
        deptRepo.save(dept);
        redirectAttributes.addFlashAttribute("message", "Department added successfully");
        return "redirect:/admin-dashboard?tab=departments";
    }

    @PostMapping("/deleteDepartment")
    public String deleteDepartment(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        try {
            deptRepo.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Department deleted successfully");
        } catch (DataIntegrityViolationException e) {
           
            redirectAttributes.addFlashAttribute("error", "Cannot delete department: It is currently assigned to one or more employees. Please reassign the employees before deleting this department.");
        } catch (Exception e) {
           
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred while deleting the department. Please try again.");
            e.printStackTrace(); 
        }
        return "redirect:/admin-dashboard?tab=departments";
    }
    @PostMapping("/deleteDesignation")
    public String deleteDesignation(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            desigRepo.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Designation deleted successfully.");
        } catch (DataIntegrityViolationException e) {
         
            redirectAttributes.addFlashAttribute("error", "Cannot delete designation: It is currently assigned to one or more employees. Please reassign the employees before deleting this designation.");
        } catch (Exception e) {
            
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred while deleting the designation. Please try again.");
            e.printStackTrace(); 
        }
        return "redirect:/admin-dashboard?tab=designations";
    }

    @PostMapping("/addDesignation")
    public String addDesignation(@RequestParam Long desigId,
            @RequestParam("title") String title,@RequestParam Date createdDate,@RequestParam String dmail,RedirectAttributes redirectAttributes) {
        Designation desig = new Designation();
        desig.setTitle(title);
        desig.setDesigId(desigId);
        desig.setDmail(dmail);
        desig.setCreatedDate(createdDate);
        desigRepo.save(desig);
        redirectAttributes.addFlashAttribute("message", "Designation added successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }
    @PostMapping("/deleteEmployee")
    public String deleteEmployee(@RequestParam("id") Long empId, RedirectAttributes redirectAttributes) {
        empRepo.deleteById(empId);
        redirectAttributes.addFlashAttribute("message", "Employee deleted successfully.");
        return "redirect:/admin-dashboard?tab=employees";
    }
   
    @PostMapping("/addEmployee")
    public String addEmployee(
            @RequestParam("empId") Long empId,
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("phone") Long phone,
            @RequestParam("hiredate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hiredate,
            @RequestParam("firstName") String firstName,
            @RequestParam("lastName") String lastName,
            @RequestParam("salary") Double salary,
            @RequestParam("deptId") Long deptId,
            @RequestParam("desigId") Long desigId,
            @RequestParam("accountNumber") Long accountNumber,
            
            RedirectAttributes redirectAttributes) {

        Employee emp = new Employee();
        Department dept = deptRepo.findById(deptId).orElse(null);
        Designation desig = desigRepo.findById(desigId).orElse(null);
        emp.setEmpId(empId);
        emp.setName(name);
        emp.setEmail(email);
        emp.setPhone(phone);
        emp.setHiredate(hiredate);
        emp.setFirstName(firstName);
        emp.setLastName(lastName);
        emp.setSalary(salary);
        emp.setDept(dept);
        emp.setDesig(desig);
        emp.setAccountNumber(accountNumber);

        empRepo.save(emp);
        redirectAttributes.addFlashAttribute("message", "Employee added successfully.");
        return "redirect:/admin-dashboard?tab=employees";
                
    }
    @PostMapping("/add-user")
    public String addUser(@RequestParam Long userId,
                          @RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          @RequestParam String role,
                          RedirectAttributes redirectAttributes) {

        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        userRepo.save(user);

        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }

    @PostMapping("/delete-user") 
    public String deleteUser(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        Optional<User> userOpt = userRepo.findById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            
            if ("admin".equalsIgnoreCase(user.getRole())) {
                redirectAttributes.addFlashAttribute("error", "Admin user cannot be deleted.");
            } else {
                userRepo.deleteById(id);
                redirectAttributes.addFlashAttribute("message", "User deleted successfully.");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "User not found.");
        }
        return "redirect:/admin-dashboard?tab=users";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}