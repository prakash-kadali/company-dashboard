package com.example.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.YearMonth; // New import for calendar logic
import java.util.HashMap; // New import for JSON response map
import java.util.List;
import java.util.Map;   // New import for JSON response map
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody; // New import for API endpoints
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Announcement;
import com.example.entity.Department;
import com.example.entity.Designation;
import com.example.entity.Employee;
import com.example.entity.Holiday; // New: Import Holiday entity
import com.example.entity.User;
import com.example.repository.AnnouncementRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
import com.example.repository.HolidayRepository; // Already present, good!
import com.example.repository.UserRepository;
import com.example.service.ExcelExportService;
import com.example.service.PdfExportService;
import com.itextpdf.text.DocumentException;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private DesignationRepository desigRepo;    
    @Autowired private EmployeeRepository empRepo;    
    @Autowired private UserRepository userRepo;
    @Autowired private HolidayRepository holidayRepo; // Already present
    @Autowired private AnnouncementRepository announcementRepo;
    @Autowired private ExcelExportService excelExportService; 
    @Autowired private PdfExportService pdfExportService;  

    @GetMapping("/login")
    public String showLoginForm(@RequestParam(value = "sessionExpired", required = false) String sessionExpired, Model model) {
        if (sessionExpired != null && sessionExpired.equals("true")) {
            model.addAttribute("errorMessage", "Your session has expired. Please log in again.");
        }
        return "login"; 
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        Optional<User> optionalUser = userRepo.findByEmailAndPasswordAndRole(email, password, role);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("User found in DB - Email: " + user.getEmail() + ", Password: " + user.getPassword() + ", Role: " + user.getRole());

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            if (!user.getRole().equals(role)) {
                model.addAttribute("error", "Incorrect role selected");
                return "login";
            }

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("password", user.getPassword());

            if ("admin".equals(role)) {
                System.out.println("Redirecting");
                return "redirect:/admin-dashboard";
            } else if ("employee".equals(role)) {
                return "redirect:/emp-dashboard";
            }
        }

        model.addAttribute("error", "Invalid credentials");
        return "login";
    }

    @GetMapping("/admin-dashboard")
    public String adminDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
            @RequestParam(defaultValue = "5") int deptSize,
            @RequestParam(defaultValue = "5") int desigSize,    
            @RequestParam(defaultValue = "5") int empSize,    
            @RequestParam(defaultValue = "5") int userSize,
            @RequestParam(defaultValue = "0") int announcementPage,
            @RequestParam(defaultValue = "5") int announcementSize,
            @RequestParam(defaultValue = "createdAt") String announcementSortField, // Default sort to createdAt
            @RequestParam(defaultValue = "desc") String announcementSortDir,
            @RequestParam(defaultValue = "deptId") String deptSortField,
            @RequestParam(defaultValue = "asc") String deptSortDir,
            @RequestParam(defaultValue = "desigId") String desigSortField,
            @RequestParam(defaultValue = "asc") String desigSortDir,
            @RequestParam(defaultValue = "empId") String empSortField,
            @RequestParam(defaultValue = "asc") String empSortDir,
            @RequestParam(defaultValue = "userId") String userSortField,
            @RequestParam(defaultValue = "asc") String userSortDir,
            @RequestParam(required = false) String openPopup,
            // New: For active tab in JSP
            @RequestParam(name = "tab", required = false) String tab, 
            Model model) {

        // Set activeTab for JSP to correctly highlight sidebar/content
        model.addAttribute("activeTab", tab);

        if (deptSize < 1 || deptSize > 100) deptSize = 5;
        if (desigSize < 1 || desigSize > 100) desigSize = 5;
        if (empSize < 1 || empSize > 100) empSize = 5;
        if (userSize < 1 || userSize > 100) userSize = 5;

        // Populate department data
        Sort deptSort = Sort.by(deptSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, deptSortField);
        Pageable deptPageable = PageRequest.of(deptPage, deptSize, deptSort);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);
        model.addAttribute("deptSize", deptSize);
        model.addAttribute("deptSortField", deptSortField);
        model.addAttribute("deptSortDir", deptSortDir);
        // Added for department badge count
        model.addAttribute("totalDepartments", deptRepo.count()); 

        // Populate designation data
        Sort desigSort = Sort.by(desigSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, desigSortField);
        Pageable desigPageable = PageRequest.of(desigPage, desigSize, desigSort);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);
        model.addAttribute("desigSize", desigSize);
        model.addAttribute("desigSortField", desigSortField);
        model.addAttribute("desigSortDir", desigSortDir);

        // Populate employee data
        Sort empSort = Sort.by(empSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, empSortField);
        Pageable empPageable = PageRequest.of(empPage, empSize, empSort);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);
        model.addAttribute("empSize", empSize);
        model.addAttribute("empSortField", empSortField);
        model.addAttribute("empSortDir", empSortDir);
        model.addAttribute("totalEmployees", employeePage.getTotalElements()); // Already present, good!

        // Populate user data
        Sort userSort = Sort.by(userSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, userSortField);
        Pageable userPageable = PageRequest.of(userPage, userSize, userSort);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);
        model.addAttribute("userSize", userSize);
        model.addAttribute("userSortField", userSortField);
        model.addAttribute("userSortDir", userSortDir);
        
     // Validate announcementSize to prevent invalid values
        if (announcementSize < 1 || announcementSize > 100) announcementSize = 5;

        // For the "Active & Archived Announcements" list on the home tab
        Sort announcementListSort = Sort.by(announcementSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, announcementSortField);
        Pageable announcementPageable = PageRequest.of(announcementPage, announcementSize, announcementListSort);
        Page<Announcement> announcementsPage = announcementRepo.findAll(announcementPageable);
        model.addAttribute("allAnnouncements", announcementsPage.getContent());
        model.addAttribute("announcementTotalPages", announcementsPage.getTotalPages());
        model.addAttribute("announcementCurrentPage", announcementPage);
        model.addAttribute("announcementSize", announcementSize);
        model.addAttribute("announcementSortField", announcementSortField);
        model.addAttribute("announcementSortDir", announcementSortDir);


        // For the scrolling banner (only active announcements)
        List<Announcement> activeAnnouncements = announcementRepo.findByActiveTrueOrderByCreatedAtDesc();
        model.addAttribute("activeAnnouncements", activeAnnouncements);
        
        model.addAttribute("openPopup", openPopup);

        return "admin-dashboard";    
    }
    
    @PostMapping("/admin/addAnnouncement")
    public String addAnnouncement(@RequestParam("message") String message,
                                  RedirectAttributes redirectAttributes) {
        if (message == null || message.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Announcement message cannot be empty.");
        } else {
            Announcement announcement = new Announcement(message);
            announcementRepo.save(announcement);
            redirectAttributes.addFlashAttribute("message", "Announcement added successfully!");
        }
        // Redirect back to the admin dashboard (home tab by default)
        return "redirect:/admin-dashboard";
    }

    @PostMapping("/admin/deleteAnnouncement")
    public String deleteAnnouncement(@RequestParam("id") Long id,
                                     RedirectAttributes redirectAttributes) {
        try {
            announcementRepo.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Announcement deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete announcement: " + e.getMessage());
            System.err.println("Error deleting announcement: " + e.getMessage());
        }
        return "redirect:/admin-dashboard";
    }

    @PostMapping("/admin/toggleAnnouncementStatus")
    public String toggleAnnouncementStatus(@RequestParam("id") Long id,
                                           RedirectAttributes redirectAttributes) {
        Optional<Announcement> optionalAnnouncement = announcementRepo.findById(id);
        if (optionalAnnouncement.isPresent()) {
            Announcement announcement = optionalAnnouncement.get();
            announcement.setActive(!announcement.isActive()); // Toggle active status
            announcementRepo.save(announcement);
            redirectAttributes.addFlashAttribute("message", "Announcement status updated successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Announcement not found.");
        }
        return "redirect:/admin-dashboard";
    }

 // --- Holiday API Endpoints (New for Calendar) ---

    // Endpoint to fetch holidays for a given month and year
    @GetMapping("/api/holidays")
    @ResponseBody // This tells Spring to serialize the return object to JSON
    public List<Holiday> getHolidays(
            @RequestParam(name = "year", required = true) Integer year,
            @RequestParam(name = "month", required = true) Integer month) {

        YearMonth yearMonth = YearMonth.of(year, month);
        LocalDate startDate = yearMonth.atDay(1);
        LocalDate endDate = yearMonth.atEndOfMonth();

        return holidayRepo.findByDateBetween(startDate, endDate);
    }

    // Endpoint to declare a new holiday
    @PostMapping("/declare-holiday")
    @ResponseBody // This tells Spring to serialize the return object to JSON
    public Map<String, Object> declareHoliday(
            @RequestParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam("description") String description,
            @RequestParam(required = false) boolean recurring) {

        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Holiday> existingHoliday = holidayRepo.findByDate(date);
            if (existingHoliday.isPresent()) {
                Holiday holidayToUpdate = existingHoliday.get();
                holidayToUpdate.setDescription(description);
                holidayRepo.save(holidayToUpdate);
                response.put("success", true);
                response.put("message", "Holiday for " + date + " updated successfully!");
            } else {
                Holiday holiday = new Holiday(date, description);
                holidayRepo.save(holiday);
                response.put("success", true);
                response.put("message", "Holiday declared successfully!");
            }
        } catch (DataIntegrityViolationException e) {
            response.put("success", false);
            response.put("message", "A holiday for this date already exists.");
            System.err.println("Data integrity violation declaring holiday: " + e.getMessage());
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to declare holiday: " + e.getMessage());
            System.err.println("Error declaring holiday: " + e.getMessage());
        }
        return response;
    } 

    @GetMapping("/emp-dashboard")
    public String showDashboard(
            @RequestParam(defaultValue = "0") int deptPage,
            @RequestParam(defaultValue = "0") int desigPage,
            @RequestParam(defaultValue = "0") int empPage,
            @RequestParam(defaultValue = "0") int userPage,
            @RequestParam(defaultValue = "5") int deptSize,
            @RequestParam(defaultValue = "5") int desigSize,    
            @RequestParam(defaultValue = "5") int empSize,    
            @RequestParam(defaultValue = "5") int userSize,
            @RequestParam(defaultValue = "0") int announcementPage,
            @RequestParam(defaultValue = "5") int announcementSize,
            @RequestParam(defaultValue = "createdAt") String announcementSortField, // Default sort to createdAt
            @RequestParam(defaultValue = "desc") String announcementSortDir,
            @RequestParam(defaultValue = "deptId") String deptSortField,
            @RequestParam(defaultValue = "asc") String deptSortDir,
            @RequestParam(defaultValue = "desigId") String desigSortField,
            @RequestParam(defaultValue = "asc") String desigSortDir,
            @RequestParam(defaultValue = "empId") String empSortField,
            @RequestParam(defaultValue = "asc") String empSortDir,
            @RequestParam(defaultValue = "userId") String userSortField,
            @RequestParam(defaultValue = "asc") String userSortDir,
            @RequestParam(required = false) String openPopup,
            Model model) {

        if (deptSize < 1 || deptSize > 100) deptSize = 5;
        if (desigSize < 1 || desigSize > 100) desigSize = 5;
        if (empSize < 1 || empSize > 100) empSize = 5;
        if (userSize < 1 || userSize > 100) userSize = 5;

        Sort deptSort = Sort.by(deptSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, deptSortField);
        Pageable deptPageable = PageRequest.of(deptPage, deptSize, deptSort);
        Page<Department> departmentsPage = deptRepo.findAll(deptPageable);
        model.addAttribute("departments", departmentsPage.getContent());
        model.addAttribute("deptTotalPages", departmentsPage.getTotalPages());
        model.addAttribute("deptCurrentPage", deptPage);
        model.addAttribute("deptSize", deptSize);
        model.addAttribute("deptSortField", deptSortField);
        model.addAttribute("deptSortDir", deptSortDir);

        Sort desigSort = Sort.by(desigSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, desigSortField);
        Pageable desigPageable = PageRequest.of(desigPage, desigSize, desigSort);
        Page<Designation> designationPage = desigRepo.findAll(desigPageable);
        model.addAttribute("designations", designationPage.getContent());
        model.addAttribute("desigTotalPages", designationPage.getTotalPages());
        model.addAttribute("desigCurrentPage", desigPage);
        model.addAttribute("desigSize", desigSize);
        model.addAttribute("desigSortField", desigSortField);
        model.addAttribute("desigSortDir", desigSortDir);

        Sort empSort = Sort.by(empSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, empSortField);
        Pageable empPageable = PageRequest.of(empPage, empSize, empSort);
        Page<Employee> employeePage = empRepo.findAll(empPageable);
        model.addAttribute("employees", employeePage.getContent());
        model.addAttribute("empTotalPages", employeePage.getTotalPages());
        model.addAttribute("empCurrentPage", empPage);
        model.addAttribute("empSize", empSize);
        model.addAttribute("empSortField", empSortField);
        model.addAttribute("empSortDir", empSortDir);
        model.addAttribute("totalEmployees", employeePage.getTotalElements());

        Sort userSort = Sort.by(userSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, userSortField);
        Pageable userPageable = PageRequest.of(userPage, userSize, userSort);
        Page<User> userPaged = userRepo.findAll(userPageable);
        model.addAttribute("users", userPaged.getContent());
        model.addAttribute("userTotalPages", userPaged.getTotalPages());
        model.addAttribute("userCurrentPage", userPage);
        model.addAttribute("userSize", userSize);
        model.addAttribute("userSortField", userSortField);
        model.addAttribute("userSortDir", userSortDir);
        
        if (announcementSize < 1 || announcementSize > 100) announcementSize = 5;

        // For the "Active & Archived Announcements" list on the home tab
        Sort announcementListSort = Sort.by(announcementSortDir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, announcementSortField);
        Pageable announcementPageable = PageRequest.of(announcementPage, announcementSize, announcementListSort);
        Page<Announcement> announcementsPage = announcementRepo.findAll(announcementPageable);
        model.addAttribute("allAnnouncements", announcementsPage.getContent());
        model.addAttribute("announcementTotalPages", announcementsPage.getTotalPages());
        model.addAttribute("announcementCurrentPage", announcementPage);
        model.addAttribute("announcementSize", announcementSize);
        model.addAttribute("announcementSortField", announcementSortField);
        model.addAttribute("announcementSortDir", announcementSortDir);


        // For the scrolling banner (only active announcements)
        List<Announcement> activeAnnouncements = announcementRepo.findByActiveTrueOrderByCreatedAtDesc();
        model.addAttribute("activeAnnouncements", activeAnnouncements);
        
        model.addAttribute("openPopup", openPopup);

        return "emp-dashboard";
    }

    @GetMapping("/export/departments/excel")
    public void exportDepartmentsToExcel(HttpServletResponse response) throws IOException {
        List<Department> departments = deptRepo.findAll();
        excelExportService.exportDepartmentsToExcel(departments, response);
    }

    @GetMapping("/export/departments/pdf")
    public void exportDepartmentsToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Department> departments = deptRepo.findAll();
        pdfExportService.exportDepartmentsToPdf(departments, response);
    }

    @GetMapping("/export/designations/excel")
    public void exportDesignationsToExcel(HttpServletResponse response) throws IOException {
        List<Designation> designations = desigRepo.findAll();
        excelExportService.exportDesignationsToExcel(designations, response);
    }

    @GetMapping("/export/designations/pdf")
    public void exportDesignationsToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Designation> designations = desigRepo.findAll();
        pdfExportService.exportDesignationsToPdf(designations, response);
    }
    
    @GetMapping("/export/employees/excel")
    public void exportEmployeesToExcel(HttpServletResponse response) throws IOException {
        List<Employee> employees = empRepo.findAll();
        excelExportService.exportEmployeesToExcel(employees, response);
    }

    @GetMapping("/export/employees/pdf")
    public void exportEmployeesToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<Employee> employees = empRepo.findAll();
        pdfExportService.exportEmployeesToPdf(employees, response);
    }

    @GetMapping("/export/users/excel")
    public void exportUsersToExcel(HttpServletResponse response) throws IOException {
        List<User> users = userRepo.findAll();
        excelExportService.exportUsersToExcel(users, response);
    }

    @GetMapping("/export/users/pdf")
    public void exportUsersToPdf(HttpServletResponse response) throws DocumentException, IOException {
        List<User> users = userRepo.findAll();
        pdfExportService.exportUsersToPdf(users, response);
    }

    @PostMapping("/addDepartment")
    public String addDepartment(@RequestParam Long deptId, @RequestParam String name,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate createdDate,
            @RequestParam String mail, RedirectAttributes redirectAttributes) {
        Department dept = new Department();
        dept.setDeptId(deptId);
        dept.setName(name);
        dept.setCreatedDate(createdDate);
        dept.setMail(mail);
        deptRepo.save(dept);
        redirectAttributes.addFlashAttribute("message", "Department added successfully");
        return "redirect:/admin-dashboard?tab=departments";
    }

    @PostMapping("/deleteDepartment")
    public String deleteDepartment(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        try {
            deptRepo.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Department deleted successfully");
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Cannot delete department: It is currently assigned to one or more employees. Please reassign the employees before deleting this department.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred while deleting the department. Please try again.");
            e.printStackTrace(); 
        }
        return "redirect:/admin-dashboard?tab=departments";
    }

    @PostMapping("/deleteDesignation")
    public String deleteDesignation(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            desigRepo.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Designation deleted successfully.");
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Cannot delete designation: It is currently assigned to one or more employees. Please reassign the employees before deleting this designation.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred while deleting the designation. Please try again.");
            e.printStackTrace(); 
        }
        return "redirect:/admin-dashboard?tab=designations";
    }

    @PostMapping("/addDesignation")
    public String addDesignation(@RequestParam Long desigId,
            @RequestParam("title") String title,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate createdDate,
            @RequestParam String dmail, RedirectAttributes redirectAttributes) {
        Designation desig = new Designation();
        desig.setTitle(title);
        desig.setDesigId(desigId);
        desig.setDmail(dmail);
        desig.setCreatedDate(createdDate);
        desigRepo.save(desig);
        redirectAttributes.addFlashAttribute("message", "Designation added successfully.");
        return "redirect:/admin-dashboard?tab=designations";
    }

    @PostMapping("/deleteEmployee")
    public String deleteEmployee(@RequestParam("id") Long empId, RedirectAttributes redirectAttributes) {
        empRepo.deleteById(empId);
        redirectAttributes.addFlashAttribute("message", "Employee deleted successfully.");
        return "redirect:/admin-dashboard?tab=employees";
    }

    @PostMapping("/employee/upload-photo")
    public String uploadPhoto(
            @RequestParam("empId") Long empId,
            @RequestParam("file") MultipartFile file,
            RedirectAttributes redirectAttributes) {
        try {
            if (!file.isEmpty()) {
                Employee employee = empRepo.findById(empId)
                        .orElseThrow(() -> new IllegalArgumentException("Invalid employee ID"));

                String fileName = "emp_" + empId + "_" + file.getOriginalFilename();
                Path path = Paths.get("src/main/resources/static/images/employees/" + fileName);
                Files.createDirectories(path.getParent());
                Files.write(path, file.getBytes());

                employee.setPhotoUrl("/images/employees/" + fileName);
                empRepo.save(employee);

                redirectAttributes.addFlashAttribute("message", "Photo uploaded successfully.");
            } else {
                redirectAttributes.addFlashAttribute("error", "Please select a file to upload.");
            }
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to upload photo: " + e.getMessage());
        }
        return "redirect:/admin-dashboard?tab=employees";
    }

    @GetMapping("/employee/photo/{empId}")
    public String viewPhoto(@RequestParam Long empId, Model model) {
        Employee employee = empRepo.findById(empId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid employee ID"));
        model.addAttribute("photoUrl", employee.getPhotoUrl() != null ? employee.getPhotoUrl() : "/images/default.jpg");
        return "view-photo";
    }

    @PostMapping("/addEmployee")
    public String addEmployee(
            @RequestParam("empId") Long empId,
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("phone") Long phone,
            @RequestParam("hiredate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hiredate,
            @RequestParam("firstName") String firstName,
            @RequestParam("lastName") String lastName,
            @RequestParam("salary") Double salary,
            @RequestParam("deptId") Long deptId,
            @RequestParam("desigId") Long desigId,
            @RequestParam("accountNumber") Long accountNumber,
            @RequestParam(value = "file", required = false) MultipartFile file,
            RedirectAttributes redirectAttributes) {

        Employee emp = new Employee();
        Department dept = deptRepo.findById(deptId).orElse(null);
        Designation desig = desigRepo.findById(desigId).orElse(null);
        emp.setEmpId(empId);
        emp.setName(name);
        emp.setEmail(email);
        emp.setPhone(phone);
        emp.setHiredate(hiredate);
        emp.setFirstName(firstName);
        emp.setLastName(lastName);
        emp.setSalary(salary);
        emp.setDept(dept);
        emp.setDesig(desig);
        emp.setAccountNumber(accountNumber);
        try {
            if (file != null && !file.isEmpty()) {
                String fileName = "emp_" + empId + "_" + file.getOriginalFilename();
                Path path = Paths.get("src/main/resources/static/images/employees/" + fileName);
                Files.createDirectories(path.getParent());
                Files.write(path, file.getBytes());
                emp.setPhotoUrl("/images/employees/" + fileName);
            }
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to upload photo: " + e.getMessage());
        }

        empRepo.save(emp);
        redirectAttributes.addFlashAttribute("message", "Employee added successfully.");
        return "redirect:/admin-dashboard?tab=employees";
    }
       
    @PostMapping("/add-user")
    public String addUser(@RequestParam Long userId,
                          @RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          @RequestParam String role,
                          RedirectAttributes redirectAttributes) {

        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        userRepo.save(user);

        redirectAttributes.addAttribute("tab", "users");
        return "redirect:/admin-dashboard?tab=users";
    }

    @PostMapping("/delete-user") 
    public String deleteUser(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        Optional<User> userOpt = userRepo.findById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            
            if ("admin".equalsIgnoreCase(user.getRole())) {
                redirectAttributes.addFlashAttribute("error", "Admin user cannot be deleted.");
            } else {
                userRepo.deleteById(id);
                redirectAttributes.addFlashAttribute("message", "User deleted successfully.");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "User not found.");
        }
        return "redirect:/admin-dashboard?tab=users";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}