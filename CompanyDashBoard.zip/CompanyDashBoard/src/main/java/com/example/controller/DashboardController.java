//package com.example.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import com.example.entity.Department;
//import com.example.entity.Designation;
//import com.example.entity.Employee;
//import com.example.repository.DepartmentRepository;
//import com.example.repository.DesignationRepository;
//import com.example.repository.EmployeeRepository;
//import com.example.repository.LeaveRepository;
//import com.example.repository.SalaryRepository;
//import com.example.repository.UserRepository;
//
//@Controller
//public class DashboardController {
//    @Autowired  private EmployeeRepository empRepo;
//    @Autowired private DepartmentRepository deptRepo;
//    @Autowired private DesignationRepository desigRepo;
//    @Autowired private UserRepository userRepo;
//    //@Autowired private RoleRepository roleRepo;
//    @Autowired private LeaveRepository leaveRepo;
//    @Autowired private SalaryRepository salaryRepo;
//   
////    @GetMapping("/dashboard")
////    public String dashboard() {       
////        return "dashboard";
////    }
////    @Autowired
////    private DepartmentRepository departmentRepository;
//
////    @GetMapping("/dashboard")
////    public String showDashboard(Model model) {
////        model.addAttribute("departments", deptRepo.findAll());
////        return "dashboard";
////    }
//
//    @GetMapping("/dashboard")
//    public String dashboard(Model model) {
//        model.addAttribute("departments", deptRepo.findAll());
//        model.addAttribute("designations", desigRepo.findAll());
////        model.addAttribute("employees", empRepo.findAll());
////        model.addAttribute("users", userRepo.findAll());
////        //model.addAttribute("roles", roleRepo.findAll());
////        model.addAttribute("leaves", leaveRepo.findAll());
////        model.addAttribute("salaries", salaryRepo.findAll());
//       return "dashboard";
//    }
//    
////    @GetMapping("/dashboard")
////    public String showDashboard(Model model) {
////        model.addAttribute("departments", deptRepo.findAll());
////        model.addAttribute("designations", desigRepo.findAll());
////        model.addAttribute("employees", empRepo.findAll());
////        return "dashboard";
////    }
////    @GetMapping("/department/{id}")
////    public String employeesByDept(@PathVariable Long id, Model model) {
////        Department dept = deptRepo.findById(id).orElse(null);
////        model.addAttribute("employees", dept.getEmployees());
////        return "employee_list";
////    }
////
////    @GetMapping("/designation/{id}")
////    public String employeesByDesignation(@PathVariable Long id, Model model) {
////        Designation desig = desigRepo.findById(id).orElse(null);
////        model.addAttribute("employees", desig.getEmployees());
////        return "employee_list";
////    }
//
////    @GetMapping("/employee/{id}")
////    public String employeeDetails(@PathVariable Long id, Model model) {
////        model.addAttribute("employee", empRepo.findById(id).orElse(null));
////        return "employee_profile";
////    }
//    
//    @GetMapping("/employees")
//    public String showEmployeeForm(Model model) {
//        model.addAttribute("employee", new Employee());
//        model.addAttribute("departments", deptRepo.findAll());
//        model.addAttribute("designations", desigRepo.findAll());
//        return "employee_form";
//    }
//    
//    @PostMapping("/employees/register")
//    public String registerEmployee(@ModelAttribute Employee employee, RedirectAttributes redirectAttributes) {
//        empRepo.save(employee);
//        redirectAttributes.addFlashAttribute("message", "Employee registered successfully!");
//        return "redirect:/employees";
//    }     
//    @GetMapping
//    public String showDepartments(Model model) {
//        model.addAttribute("departments", deptRepo.findAll());
//        return "dashboard"; // Replace with your JSP page name
//    }
//
//    @PostMapping("/add")
//    public String addDepartment(@RequestParam("name") String name, RedirectAttributes redirectAttributes) {
//        Department dept = new Department();
//        dept.setName(name);
//        deptRepo.save(dept);
//        redirectAttributes.addFlashAttribute("message", "Department added successfully!");
//        return "redirect:/departments";
//    }
////}
////    @GetMapping("/departments")
////    public String showDepartments(Model model) {
////        model.addAttribute("departments", deptRepo.findAll());
////        model.addAttribute("department", new Department());
////        return "departments";                                                                                                                 
////    }
////
////    @PostMapping("/departments")
////    public String addDepartment(@ModelAttribute Department department){
////        deptRepo.save(department);
////        return "redirect:/departments";
////    }
//   
//    @GetMapping("/designations")
//    public String showDesignations(Model model) {
//        model.addAttribute("designations", desigRepo.findAll());
//        model.addAttribute("designation", new Designation());
//        return "designations";
//    }
//
//    @PostMapping("/designations")
//    public String addDesignation(@ModelAttribute Designation designation) {
//        desigRepo.save(designation);
//        return "redirect:/designations";
//    }
//}


package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Department;
import com.example.entity.Employee;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
import com.example.repository.SalaryRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {

    @Autowired
    private DepartmentRepository deptRepo;

    @Autowired
    private DesignationRepository desigRepo;
    
    @Autowired  
    private EmployeeRepository empRepo;
    
    @Autowired
    private SalaryRepository salaryRepo;


    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("departments", deptRepo.findAll());
        model.addAttribute("designations", desigRepo.findAll());
        model.addAttribute("employees", empRepo.findAll()); // Add this line
        model.addAttribute("salaries", salaryRepo.findAll());

        return "dashboard";
    }

    @PostMapping("/add")
    public String addDepartment(@RequestParam("name") String name, RedirectAttributes redirectAttributes) {
        Department dept = new Department();
        dept.setName(name);
        deptRepo.save(dept);
        redirectAttributes.addFlashAttribute("message", "Department added successfully!");
        return "redirect:/dashboard";
    }
    

    @PostMapping("/employeeLogin")
    public String loginEmployee(@RequestParam("email") String email,
                                 @RequestParam("password") String password,
                                 Model model) {
        Employee employee = empRepo.findByEmailAndPassword(email, password);

        if (employee != null) {
            model.addAttribute("loggedInEmployee", employee);
            model.addAttribute("showEmployeePopup", true); // Flag to open popup
        } else {
            model.addAttribute("message", "Invalid credentials. Please try again.");
        }

        return "dashboard"; 
    }
    @GetMapping("/employeeLogout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/dashboard"; 
    }
}

