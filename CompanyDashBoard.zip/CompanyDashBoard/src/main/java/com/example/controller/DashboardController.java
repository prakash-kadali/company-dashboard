
package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.entity.Department;
import com.example.entity.User;
import com.example.repository.AdminRepository;
import com.example.repository.DepartmentRepository;
import com.example.repository.DesignationRepository;
import com.example.repository.EmployeeRepository;
//import com.example.repository.SalaryRepository;
import com.example.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private DesignationRepository desigRepo; 
    @Autowired private EmployeeRepository empRepo;  
    @Autowired private AdminRepository adminRepo;
    @Autowired private UserRepository userRepo;
   
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; 
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        Optional<User> optionalUser = userRepo.findByEmailAndPasswordAndRole(email, password,role);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            System.out.println("User found in DB - Email: " + user.getEmail() + ", Password: " + user.getPassword() + ", Role: " + user.getRole());

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            if (!user.getRole().equals(role)) {
                model.addAttribute("error", "Incorrect role selected");
                return "login";
            }

            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("password", user.getPassword());

            if ("admin".equals(role)) {
                System.out.println("Redirecting");

                return "admin-dashboard";
                
            } else if ("employee".equals(role)) {
                return "emp-dashboard";
            }
        }

        model.addAttribute("error", "Invalid credentials");
        return "login";
    }
    @GetMapping("/admin-dashboard")
    public String showDashboard(Model model) {
    	 List<Department> departments = deptRepo.findAll();
    	 System.out.println("Departments");
         model.addAttribute("departments", departments);
             model.addAttribute("designations", desigRepo.findAll());
             model.addAttribute("employees", empRepo.findAll());
             //model.addAttribute("salaries", salRepo.findAll());
            // model.addAttribute("leaves", leaveRequestRepo.findAll());

           
        return "admin-dashboard"; 
    }
    @GetMapping("/emp-dashboard")
    public String showwDashboard(Model model) {
    	List<Department> departments = deptRepo.findAll();
    	System.out.println("Departments Count: " + departments.size());
   	 System.out.println("Departments");
        model.addAttribute("departments", departments);
        return "emp-dashboard"; 
    }



    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
//    @GetMapping("/admin-dashboard")
//    public String dashboard(Model model) {
//        List<Department> departments = deptRepo.findAll();
//        model.addAttribute("departments", departments);
//       
//        return "dashboard"; 
//    }

//
//    @PostMapping("/addDepartment")
//    public String addDepartment(@RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = new Department();
//        dept.setName(name);
//        deptRepo.save(dept);
//        redirectAttributes.addFlashAttribute("message", "Department added.");
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/updateDepartment")
//    public String updateDepartment(@RequestParam Long dept_id, @RequestParam String name, RedirectAttributes redirectAttributes) {
//        Department dept = deptRepo.findById(dept_id).orElse(null);
//        if (dept != null) {
//            dept.setName(name);
//            deptRepo.save(dept);
//            redirectAttributes.addFlashAttribute("message", "Department updated.");
//        }
//        return "redirect:/admin-dashboard";
//    }
//
//    @PostMapping("/deleteDepartment")
//    public String deleteDepartment(@RequestParam Long dept_id, RedirectAttributes redirectAttributes) {
//        deptRepo.deleteById(dept_id);
//        redirectAttributes.addFlashAttribute("message", "Department deleted.");
//        return "redirect:/admin-dashboard";
//    }
}
