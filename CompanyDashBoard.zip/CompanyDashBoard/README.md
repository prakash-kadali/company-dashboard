# Company Dashboard Application

A Spring Boot-based company dashboard application with role-based access control, featuring employee management, department management, and leave request functionality.

## Features

- User authentication with JWT
- Role-based access control (Admin and Employee roles)
- Department management
- Designation management
- User management
- Leave request management
- Profile management

## Prerequisites

- Java 17 or higher
- Maven
- MySQL 8.0 or higher
- IDE (IntelliJ IDEA, Eclipse, or VS Code)

## Database Setup

1. Create a MySQL database:
```sql
CREATE DATABASE company_dashboard;
```

2. Update the database credentials in `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/company_dashboard
spring.datasource.username=your_username
spring.datasource.password=your_password
```

## Running the Application

1. Clone the repository
2. Navigate to the project directory
3. Run the application:
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

## Sample Data

The application comes with sample data that is automatically populated on startup:

### Departments
- Information Technology
- Human Resources
- Finance

### Designations
- Senior Developer (IT)
- Junior Developer (IT)
- HR Manager (HR)
- Finance Manager (Finance)

### Users
1. Admin User
   - Email: admin@company.com
   - Password: admin123
   - Role: ADMIN

2. IT Employee
   - Email: john@company.com
   - Password: employee123
   - Role: EMPLOYEE
   - Department: IT
   - Designation: Senior Developer

3. HR Employee
   - Email: jane@company.com
   - Password: employee123
   - Role: EMPLOYEE
   - Department: HR
   - Designation: HR Manager

4. Finance Employee
   - Email: mike@company.com
   - Password: employee123
   - Role: EMPLOYEE
   - Department: Finance
   - Designation: Finance Manager

## Testing the Application

1. Use the provided `api-test.http` file to test the API endpoints
2. First, login as admin or employee to get the JWT token
3. Use the token in subsequent requests

### Testing Steps

1. Login as Admin:
```http
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
    "email": "admin@company.com",
    "password": "admin123"
}
```

2. Copy the JWT token from the response

3. Use the token in subsequent requests:
```http
GET http://localhost:8080/api/departments
Authorization: Bearer your_jwt_token
```

## API Endpoints

### Authentication
- POST `/api/auth/login` - Login and get JWT token

### Departments (Admin only)
- GET `/api/departments` - Get all departments
- POST `/api/departments` - Create new department
- GET `/api/departments/{id}` - Get department by ID
- PUT `/api/departments/{id}` - Update department
- DELETE `/api/departments/{id}` - Delete department

### Designations (Admin only)
- GET `/api/designations` - Get all designations
- POST `/api/designations` - Create new designation
- GET `/api/designations/{id}` - Get designation by ID
- PUT `/api/designations/{id}` - Update designation
- DELETE `/api/designations/{id}` - Delete designation
- GET `/api/designations/department/{departmentId}` - Get designations by department

### Users
- GET `/api/users` - Get all users (Admin only)
- POST `/api/users` - Create new user (Admin only)
- GET `/api/users/{id}` - Get user profile
- PUT `/api/users/{id}` - Update user profile
- DELETE `/api/users/{id}` - Delete user (Admin only)

### Leave Requests
- GET `/api/leave-requests` - Get all leave requests (Admin only)
- POST `/api/leave-requests` - Create leave request
- GET `/api/leave-requests/{id}` - Get leave request by ID
- GET `/api/leave-requests/user/{userId}` - Get leave requests by user
- PUT `/api/leave-requests/{id}/status` - Update leave request status (Admin only)

## Security

- JWT-based authentication
- Password encryption using BCrypt
- Role-based access control
- CORS configuration
- Request validation

## Error Handling

The application includes comprehensive error handling for:
- Authentication failures
- Authorization failures
- Invalid requests
- Resource not found
- Validation errors

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License. 